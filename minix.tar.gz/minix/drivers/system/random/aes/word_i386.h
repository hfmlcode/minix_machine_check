typedef unsigned char byte;
typedef unsigned char word8;
typedef unsigned short word16;
typedef unsigned word32;
#define STRICT_ALIGN 1

/*
 * $PchId: word_i386.h,v 1.1 2003/09/29 09:20:13 philip Exp $
 */
