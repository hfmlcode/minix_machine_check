README file for the Dec21140A ethernet board driver as emulated by 
Microsoft VirtualPC 2007.

created August 2009, Nicolas Tittley (first.last@gmail)

LIMITATIONS:
------------

This driver supports only the Dec21140A as emulated by VPC2007. It is
untested in any other environment and will probably panic if you use it
outside VPC2007.

The driver supports bridged, nat and local network settings.
