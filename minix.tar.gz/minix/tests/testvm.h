
struct info {
	/* info to testvm */
	int big;	/* do BIG mode */

	/* info from testvm */
	int result;	/* error code */
};
