#include "syslib.h"

/* sys_mcinitialisation */
int sys_mcinitialisation() {
	message m;
	return(_kernel_call(SYS_MCINITIALISATION, &m));
}


/* sys_mcehandler */
int sys_mcehandler(endpt, log_info, handle_sign) 
endpoint_t endpt;		/* Location of log info structure */
vir_bytes log_info;
int handle_sign;	
{
	message m;
	m.m_lsys_krn_sys_machine_error.info = log_info;
	m.m_lsys_krn_sys_machine_error.endpt = endpt;
	m.m_lsys_krn_sys_machine_error.handle_sign = handle_sign;
	
	return(_kernel_call(SYS_MCEHANDLER, &m));
}

