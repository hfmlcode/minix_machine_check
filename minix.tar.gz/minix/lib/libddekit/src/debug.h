#ifndef DDEKIT_DEBUG_MACROS_H
#define DDEKIT_DEBUG_MACROS_H

#include <ddekit/printf.h>
#include <ddekit/debug.h>

#endif /* DDEKIT_DEBUG_MACROS_H */
