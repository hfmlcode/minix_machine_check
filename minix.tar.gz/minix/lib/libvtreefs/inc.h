#include <minix/drivers.h>
#include <minix/vtreefs.h>
#include <minix/fsdriver.h>

#include <assert.h>

#include "glo.h"
#include "proto.h"
#include "inode.h"
