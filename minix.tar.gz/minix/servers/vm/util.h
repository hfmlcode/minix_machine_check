
#ifndef _UTIL_H
#define _UTIL_H 1

#include "vm.h"
#include "glo.h"

#define ELEMENTS(a) (int)(sizeof(a)/sizeof((a)[0]))

#endif

