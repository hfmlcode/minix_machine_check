#ifndef __GLO_ARM_H__
#define __GLO_ARM_H__

#include "kernel/kernel.h"
#include "arch_proto.h"

EXTERN struct tss_s tss[CONFIG_MAX_CPUS];

#endif /* __GLO_ARM_H__ */
