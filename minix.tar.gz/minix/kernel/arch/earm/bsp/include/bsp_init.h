#ifndef _BSP_INIT_H_
#define _BSP_INIT_H_

/* BSP init */
void bsp_init(void);

#endif /* __BSP_INIT_H__ */
