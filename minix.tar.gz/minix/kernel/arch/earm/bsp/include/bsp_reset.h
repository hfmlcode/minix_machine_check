#ifndef _BSP_RESET_H_
#define _BSP_RESET_H_

void bsp_reset_init(void);
void bsp_reset(void);
void bsp_poweroff(void);
void bsp_disable_watchdog(void);

#endif /* _BSP_RESET_H_ */
