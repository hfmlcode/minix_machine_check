#ifndef __CLOCK_ARM_H__
#define __CLOCK_ARM_H__

void arch_timer_int_handler(void);

#endif /* __CLOCK_ARM_H__ */
