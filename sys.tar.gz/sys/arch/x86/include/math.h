/*	$NetBSD: math.h,v 1.2 2003/10/28 00:55:28 kleink Exp $	*/

#define	__HAVE_LONG_DOUBLE
#define	__HAVE_NANF
