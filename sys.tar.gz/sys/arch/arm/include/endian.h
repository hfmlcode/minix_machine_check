/*	$NetBSD: endian.h,v 1.3 2001/06/23 12:20:27 bjh21 Exp $	*/

#include <sys/endian.h>
