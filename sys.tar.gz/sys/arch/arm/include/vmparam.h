/* $NetBSD: vmparam.h,v 1.3 2013/05/01 12:00:51 matt Exp $ */

#include <arm/arm32/vmparam.h>
