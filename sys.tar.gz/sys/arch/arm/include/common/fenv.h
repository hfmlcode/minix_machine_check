/* $NetBSD: fenv.h,v 1.1 2013/05/01 12:01:55 matt Exp $ */

#include <arm/fenv.h>
