/*	$NetBSD: isadmavar.h,v 1.2 2008/12/14 17:03:43 christos Exp $	*/

void isa_dmacascade(int);
