/*	$NetBSD: cputypes.h,v 1.15 2007/01/01 20:56:59 ad Exp $	*/

#include <x86/cputypes.h>
