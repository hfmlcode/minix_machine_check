/*	$NetBSD: acpi_machdep.h,v 1.7 2003/05/11 18:18:08 fvdl Exp $	*/

#include <x86/acpi_machdep.h>
