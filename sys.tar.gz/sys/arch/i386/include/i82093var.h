/*	 $NetBSD: i82093var.h,v 1.7 2003/02/26 21:29:00 fvdl Exp $ */

#include <x86/i82093var.h>
