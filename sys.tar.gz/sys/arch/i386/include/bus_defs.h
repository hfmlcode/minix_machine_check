/*	$NetBSD: bus_defs.h,v 1.1 2011/07/01 17:09:59 dyoung Exp $	*/

#include <x86/bus_defs.h>
