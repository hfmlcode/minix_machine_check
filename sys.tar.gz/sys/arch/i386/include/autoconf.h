/*	$NetBSD: autoconf.h,v 1.3 2011/10/18 23:25:20 dyoung Exp $	*/

#include <x86/autoconf.h>
