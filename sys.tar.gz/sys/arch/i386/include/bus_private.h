/*	$NetBSD: bus_private.h,v 1.2 2005/12/11 12:17:43 christos Exp $	*/

#include <x86/bus_private.h>
