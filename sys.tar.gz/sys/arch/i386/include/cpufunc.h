/*	$NetBSD: cpufunc.h,v 1.40 2007/10/17 19:54:56 garbled Exp $	*/

#include <x86/cpufunc.h>
