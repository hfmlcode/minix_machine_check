/*	$NetBSD: isa_machdep.h,v 1.22 2003/02/27 00:12:21 fvdl Exp $	*/

#include <x86/isa_machdep.h>
