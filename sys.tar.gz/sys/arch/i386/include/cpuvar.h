/* 	$NetBSD: cpuvar.h,v 1.5 2003/03/01 18:30:03 fvdl Exp $ */

#include <x86/cpuvar.h>
