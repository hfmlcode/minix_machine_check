/*	$NetBSD: pcb.h,v 1.1 2001/11/25 15:56:05 thorpej Exp $	*/

#include <arm/pcb.h>
