/*	$NetBSD: trap.h,v 1.1 2001/11/25 15:56:06 thorpej Exp $	*/

#include <arm/trap.h>
