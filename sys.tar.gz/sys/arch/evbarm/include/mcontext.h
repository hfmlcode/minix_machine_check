/*	$NetBSD: mcontext.h,v 1.2 2003/01/17 22:45:39 thorpej Exp $	*/

#include <arm/mcontext.h>
