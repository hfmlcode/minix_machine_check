/*	$NetBSD: frame.h,v 1.2 2001/11/25 15:56:04 thorpej Exp $	*/

#include <arm/arm32/frame.h>
