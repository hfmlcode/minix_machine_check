/*	$NetBSD: int_fmtio.h,v 1.1 2001/11/25 15:56:04 thorpej Exp $	*/

#include <arm/int_fmtio.h>
