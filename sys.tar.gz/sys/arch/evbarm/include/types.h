/*	$NetBSD: types.h,v 1.12 2011/11/26 16:31:40 skrll Exp $	*/

#ifndef _EVBARM_TYPES_H_
#define	_EVBARM_TYPES_H_

#include <arm/arm32/types.h>

#define	__HAVE_NEW_STYLE_BUS_H

#endif
