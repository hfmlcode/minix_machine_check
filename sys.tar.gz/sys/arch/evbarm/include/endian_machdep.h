/*	$NetBSD: endian_machdep.h,v 1.1 2001/11/25 15:56:04 thorpej Exp $	*/

#include <arm/endian_machdep.h>
