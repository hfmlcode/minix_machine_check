/*	$NetBSD: disklabel.h,v 1.5 2013/05/07 20:42:46 matt Exp $	*/

#if HAVE_NBTOOL_CONFIG_H
#include <nbinclude/arm/disklabel.h>
#else
#include <arm/disklabel.h>
#endif /* HAVE_NBTOOL_CONFIG_H */
