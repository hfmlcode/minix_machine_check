/*	$NetBSD: pmc.h,v 1.1 2002/08/07 05:15:12 briggs Exp $	*/

#include <arm/pmc.h>
