/* $NetBSD: isa_machdep.h,v 1.2 2005/12/11 12:17:09 christos Exp $ */

#ifndef _EVBARM_ISA_MACHDEP_H_
#define _EVBARM_ISA_MACHDEP_H_
#include <arm/isa_machdep.h>

#endif /* _EVBARM_ISA_MACHDEP_H_ */
